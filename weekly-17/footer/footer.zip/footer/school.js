$(document).ready(function(){
    $("#close").click(function(){
        $(".pop_up").css("display","none");
    })
})